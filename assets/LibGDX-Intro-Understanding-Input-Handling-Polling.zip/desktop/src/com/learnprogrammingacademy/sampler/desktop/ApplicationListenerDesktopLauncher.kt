package com.learnprogrammingacademy.sampler.desktop

import com.badlogic.gdx.backends.lwjgl.LwjglApplication
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration
import com.learnprogrammingacademy.sampler.ApplicationListenerSample
import com.learnprogrammingacademy.sampler.GdxSamplerGame

/**
 * @author goran on 26/10/2017.
 */

fun main(args: Array<String>) {
    LwjglApplication(ApplicationListenerSample(), LwjglApplicationConfiguration())
}